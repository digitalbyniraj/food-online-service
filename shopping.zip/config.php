


<?php
$conn=mysqli_connect("localhost","root","","shopping");
if($conn->connect_error)
{
	echo $conn->connect_error;
}

?>